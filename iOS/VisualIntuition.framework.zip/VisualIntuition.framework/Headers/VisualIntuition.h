//
//  VisualIntuition.h
//  VisualIntuition
//
//  Created by Jakub on 02/08/16.
//  Copyright © 2016 NexRef. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VisualIntuition.
FOUNDATION_EXPORT double VisualIntuitionVersionNumber;

//! Project version string for VisualIntuition.
FOUNDATION_EXPORT const unsigned char VisualIntuitionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VisualIntuition/PublicHeader.h>

#import <VisualIntuition/NRCameraViewController.h>
